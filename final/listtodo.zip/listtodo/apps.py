from django.apps import AppConfig


class ListtodoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'listtodo'
